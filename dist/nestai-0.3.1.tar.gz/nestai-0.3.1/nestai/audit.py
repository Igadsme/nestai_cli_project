from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from .models import AuditEntry

CONFIG_PATH = Path.home() / ".nestai" / "config.json"
HISTORY_ROOT = Path.home() / ".nestai" / "history"


class AuditTamperError(Exception):
    """Raised when history integrity is violated in enterprise mode."""


def _ensure_base_dirs() -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    HISTORY_ROOT.mkdir(parents=True, exist_ok=True)


def _default_config() -> Dict[str, Any]:
    # mode: "individual" or "enterprise"
    return {
        "mode": "individual",
    }


def load_config() -> Dict[str, Any]:
    _ensure_base_dirs()
    if not CONFIG_PATH.exists():
        with CONFIG_PATH.open("w", encoding="utf-8") as f:
            json.dump(_default_config(), f, indent=2)
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def get_mode() -> str:
    cfg = load_config()
    mode = cfg.get("mode", "individual")
    if mode not in ("individual", "enterprise"):
        mode = "individual"
    return mode


def _project_id(cwd: Optional[str] = None) -> str:
    if cwd is None:
        cwd = os.getcwd()
    return hashlib.sha256(os.path.abspath(cwd).encode("utf-8")).hexdigest()


def _history_path(project_id: str) -> Path:
    return HISTORY_ROOT / f"{project_id}.log"


def _compute_entry_hash(entry: Dict[str, Any], prev_hash: Optional[str]) -> str:
    h = hashlib.sha256()
    if prev_hash:
        h.update(prev_hash.encode("utf-8"))
    # Ensure deterministic ordering
    payload = json.dumps(entry, sort_keys=True).encode("utf-8")
    h.update(payload)
    return h.hexdigest()


def read_history(project_id: str) -> List[Dict[str, Any]]:
    path = _history_path(project_id)
    if not path.exists():
        return []

    entries: List[Dict[str, Any]] = []
    prev_hash: Optional[str] = None
    mode = get_mode()

    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            data = json.loads(line)
            entries.append(data)

            if mode == "enterprise":
                core = {
                    k: v
                    for k, v in data.items()
                    if k not in ("prev_hash", "entry_hash")
                }
                expected_hash = _compute_entry_hash(core, prev_hash)
                if data.get("entry_hash") != expected_hash:
                    raise AuditTamperError("History file has been tampered with.")
                prev_hash = expected_hash

    return entries


def append_history_entry(
    original_prompt: str,
    final_prompt: Optional[str],
    controller_result: Dict[str, Any],
    red_team_results: List[Dict[str, Any]],
    blue_team_results: List[Dict[str, Any]],
) -> None:
    _ensure_base_dirs()
    project_id = _project_id()
    path = _history_path(project_id)

    existing = read_history(project_id)
    prev_hash = existing[-1].get("entry_hash") if existing else None

    entry = AuditEntry(
        project_id=project_id,
        original_prompt=original_prompt,
        final_prompt=final_prompt,
        controller_result=controller_result,
        red_team_results=red_team_results,
        blue_team_results=blue_team_results,
        timestamp=time.time(),
        prev_hash=prev_hash,
        entry_hash=None,
    )

    # Compute hash chain
    entry_dict = asdict(entry)
    entry_dict_without_hash = {
        k: v for k, v in entry_dict.items() if k != "entry_hash"
    }
    entry_hash = _compute_entry_hash(entry_dict_without_hash, prev_hash)
    entry.entry_hash = entry_hash

    to_write = asdict(entry)

    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(to_write, sort_keys=True) + "\n")
