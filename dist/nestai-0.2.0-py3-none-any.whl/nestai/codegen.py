from .models import call_model_text

CODEGEN_MODEL = "gpt-4o-mini"

CODEGEN_SYSTEM_PROMPT = """
You are the CODE GENERATOR agent.
Output ONLY secure code implementing the hardened prompt.
No explanations, no markdown.
"""

def generate_code_preview(secure_prompt: str):
    return call_model_text(
        model_name=CODEGEN_MODEL,
        system_prompt=CODEGEN_SYSTEM_PROMPT,
        user_prompt=secure_prompt,
        temperature=0.2,
    )
