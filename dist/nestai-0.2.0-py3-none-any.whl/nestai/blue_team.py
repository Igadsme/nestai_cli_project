# nestai/blue_team.py – blue team using categorized findings

from typing import Dict, List
from .models import call_model_text
from .red_team import AGENT_LABELS

BLUE_TEAM_MODEL = "gpt-4o-mini"

BLUE_TEAM_SYSTEM_PROMPT = """
You are the BLUE TEAM security agent.

You receive:
- the original user prompt
- categorized red-team findings from multiple specialized agents

Your job is to:
- rewrite the user's prompt into a SECURE, HARDENED specification
- keep the original functional intent
- address ALL issues raised by the red-team agents
- enforce strong security defaults (OWASP ASVS style)
- be explicit about security requirements

OUTPUT RULES:
- Output ONLY the rewritten secure prompt – no explanations, no markdown.
"""


def _format_findings(findings_by_agent: Dict[str, List[str]]) -> str:
    """
    Turn the per-agent findings dict into a readable text block for the model.
    """
    if not findings_by_agent:
        return "No findings provided; still apply best security practices."

    sections: List[str] = []
    for agent_key, issues in findings_by_agent.items():
        label = AGENT_LABELS.get(agent_key, agent_key)
        if not issues:
            continue
        lines = [f"{label} findings:"]
        for issue in issues:
            lines.append(f"- {issue}")
        sections.append("\n".join(lines))

    if not sections:
        return "No findings provided; still apply best security practices."

    return "\n\n".join(sections)


def blue_agent_rewrite(original_prompt: str, findings_by_agent: Dict[str, List[str]]) -> str:
    """
    Rewrite the original prompt into a secure spec using per-agent findings.
    """
    findings_text = _format_findings(findings_by_agent)

    user_prompt = f"""
Original user prompt:
{original_prompt}

Red-team findings by category:
{findings_text}

Rewrite the original prompt into a SECURE, HARDENED specification that:
- keeps the original intent
- addresses ALL of the above findings
Output ONLY the secure rewritten prompt.
"""
    return call_model_text(
        model_name=BLUE_TEAM_MODEL,
        system_prompt=BLUE_TEAM_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.2,
    )
