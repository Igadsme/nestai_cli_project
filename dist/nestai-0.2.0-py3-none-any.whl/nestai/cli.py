# nestai/cli.py – CLI entrypoint

import argparse
from .controller import run_pipeline
from .red_team import AGENT_LABELS


def main():
    parser = argparse.ArgumentParser(
        description="NestAI – Multi-agent secure prompt hardener (Red Team + Blue Team + Codegen)"
    )
    parser.add_argument(
        "prompt",
        nargs="+",
        help="Prompt to secure (e.g. 'build a login API in python')",
    )
    args = parser.parse_args()

    original_prompt = " ".join(args.prompt)
    result = run_pipeline(original_prompt)

    print("=== Original Prompt ===")
    print(result["original_prompt"])
    print()

    print("=== Red Team Findings (by agent) ===")
    findings_by_agent = result.get("findings_by_agent", {})

    if not findings_by_agent or all(
        not issues for issues in findings_by_agent.values()
    ):
        print("No issues detected (or red team did not return findings).")
    else:
        for agent_key, issues in findings_by_agent.items():
            label = AGENT_LABELS.get(agent_key, agent_key)
            print(f"[{label}]")
            if issues:
                for issue in issues:
                    print(f"- {issue}")
            else:
                print("  (no findings)")
            print()
    print()

    print("=== Final Secure Prompt ===")
    print(result["secure_prompt"])
    print()

    print("=== Code Preview (from secure prompt) ===")
    print("```")
    print(result["code_preview"])
    print("```")
