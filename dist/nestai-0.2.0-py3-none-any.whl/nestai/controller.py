# nestai/controller.py – orchestrator

from typing import Dict, Any, List
from .red_team import run_red_team
from .blue_team import blue_agent_rewrite
from .codegen import generate_code_preview


def run_pipeline(original_prompt: str) -> Dict[str, Any]:
    """
    Main NestAI pipeline:
      1. Multi-agent Red Team analyzes vulnerabilities (per category).
      2. Blue Team rewrites the prompt securely, using all findings.
      3. Codegen generates a secure code example.
    """
    # 1. Multi-agent Red Team
    findings_by_agent: Dict[str, List[str]] = run_red_team(original_prompt)

    # 2. Blue Team rewrite
    secure_prompt: str = blue_agent_rewrite(original_prompt, findings_by_agent)

    # 3. Codegen from secure prompt
    code_preview: str = generate_code_preview(secure_prompt)

    return {
        "original_prompt": original_prompt,
        "findings_by_agent": findings_by_agent,
        "secure_prompt": secure_prompt,
        "code_preview": code_preview,
    }
