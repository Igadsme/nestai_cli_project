from __future__ import annotations

import json
from typing import List

from .models import AgentResult, call_json_model

BLUE_AGENT_SYSTEM_PROMPT = """
You are a Blue Team Defensive Prompt Engineer.

Your job is to take the user's original prompt and:
- preserve the legitimate intent,
- add strong security constraints,
- clarify vague requirements,
- and harden it against misuse.

Return a JSON object:
{
  "agent_name": "blue_X",   // the caller will set the actual name
  "rewritten_prompt": "secure, clarified version of the user's prompt",
  "constraints": [
    "specific security constraint 1",
    "specific security constraint 2"
  ],
  "assumptions": [
    "explicit assumption 1",
    "explicit assumption 2"
  ],
  "notes": "optional explanation"
}

Do NOT change the business goal of the prompt, only make it safer, clearer, and more robust.
Always return valid JSON.
"""


class BlueTeam:
    def __init__(self, num_agents: int = 5) -> None:
        self.num_agents = num_agents
        self.system_prompt = BLUE_AGENT_SYSTEM_PROMPT

    def run_all(self, user_prompt: str) -> List[AgentResult]:
        results: List[AgentResult] = []
        for i in range(1, self.num_agents + 1):
            name = f"blue_{i}"
            payload = (
                f"Agent name: {name}\n"
                f"User prompt: {user_prompt}\n\n"
                f"Rewrite and harden this prompt according to your instructions."
            )
            parsed = call_json_model(self.system_prompt, payload)
            # Ensure the agent_name is set correctly
            parsed["agent_name"] = name
            results.append(
                AgentResult(
                    name=name,
                    role="blue",
                    raw=json.dumps(parsed, indent=2),
                    parsed=parsed,
                )
            )
        return results
