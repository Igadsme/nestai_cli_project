from __future__ import annotations

import os

from .models import get_client, MODEL_NAME

CODEGEN_SYSTEM_PROMPT = """
You are a senior software engineer.

You receive a FINAL, security-hardened prompt describing what code to generate.
Your job is to:
- produce clear, well-structured, production-quality code,
- follow the security constraints explicitly,
- avoid including secrets, test keys, or unsafe shortcuts.

Return ONLY the code as plain text, without explanation, unless the prompt explicitly asks for comments.
"""


def generate_code(final_prompt: str) -> str:
    """
    Generate code using the FINAL unified prompt.
    This uses the same model client, but we do not require JSON here.
    """
    client = get_client()
    resp = client.chat.completions.create(
        model=os.getenv("NESTAI_CODEGEN_MODEL", MODEL_NAME),
        messages=[
            {"role": "system", "content": CODEGEN_SYSTEM_PROMPT},
            {"role": "user", "content": final_prompt},
        ],
        temperature=0.1,
    )
    return resp.choices[0].message.content or ""
