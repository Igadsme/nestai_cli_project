from __future__ import annotations

import json
from typing import Dict, List

from .models import AgentResult, call_json_model

# ===============================================================
# SHARED JSON-STRICT HEADER (injected into every agent prompt)
# ===============================================================

JSON_STRICT_HEADER = """
YOU MUST ALWAYS RETURN A VALID JSON OBJECT.
NEVER return plain text.
NEVER return markdown.
NEVER use ```json or code fences.
NEVER output explanations outside of JSON.
Return ONLY one JSON object with no surrounding text.
"""

# ===============================================================
# RED TEAM AGENTS — FULLY JSON-ENFORCED
# ===============================================================

RED_TEAM_AGENTS: Dict[str, str] = {
    "auth_red": f"""
{JSON_STRICT_HEADER}

You are the Authentication Red Team Agent.

Analyze the user's prompt for authentication weaknesses:
- missing password hashing
- missing MFA
- brute-force vulnerabilities
- weak session handling

Return JSON exactly in this schema:
{{
  "agent_name": "auth_red",
  "risks": ["string", "..."],
  "severity": "low|medium|high|critical",
  "suggested_constraints": ["string", "..."],
  "notes": "optional text"
}}
""",

    "rbac_red": f"""
{JSON_STRICT_HEADER}

You are the Authorization / RBAC Red Team Agent.

Identify:
- privilege escalation paths
- missing role checks
- improper access restrictions

Return JSON:
{{
  "agent_name": "rbac_red",
  "risks": ["string"],
  "severity": "low|medium|high|critical",
  "suggested_constraints": ["string"],
  "notes": "optional"
}}
""",

    "injection_red": f"""
{JSON_STRICT_HEADER}

You are the Injection & Input Validation Red Team Agent.

Find:
- SQLi
- XSS
- command injection
- template injection

Return JSON:
{{
  "agent_name": "injection_red",
  "risks": ["string"],
  "severity": "low|medium|high|critical",
  "suggested_constraints": ["string"],
  "notes": "optional"
}}
""",

    "crypto_red": f"""
{JSON_STRICT_HEADER}

You are the Data Protection & Cryptography Red Team Agent.

Evaluate:
- plaintext secrets
- weak encryption
- no TLS/HTTPS
- improper key storage

Return JSON:
{{
  "agent_name": "crypto_red",
  "risks": ["string"],
  "severity": "low|medium|high|critical",
  "suggested_constraints": ["string"],
  "notes": "optional"
}}
""",

    "logic_red": f"""
{JSON_STRICT_HEADER}

You are the Logic Exploitation Red Team Agent.

Identify:
- business logic abuse
- race conditions
- replay attacks
- workflow flaws

Return JSON:
{{
  "agent_name": "logic_red",
  "risks": ["string"],
  "severity": "low|medium|high|critical",
  "suggested_constraints": ["string"],
  "notes": "optional"
}}
""",

    "api_red": f"""
{JSON_STRICT_HEADER}

You are the API / Protocol Abuse Red Team Agent.

Identify:
- over-posting / mass assignment
- insecure endpoints
- ID enumeration
- missing rate limits

Return JSON:
{{
  "agent_name": "api_red",
  "risks": ["string"],
  "severity": "low|medium|high|critical",
  "suggested_constraints": ["string"],
  "notes": "optional"
}}
""",
}

# ===============================================================
# MALICIOUS AGENT — FULLY JSON-STRICT
# ===============================================================

MALICIOUS_SYSTEM_PROMPT = f"""
{JSON_STRICT_HEADER}

You are the Malicious Adversary Agent.

Your job:

1. Detect malicious intent such as:
   - disabling authentication
   - bypassing security controls
   - hacking, exploitation, malware
   - unauthorized access
   - security evasion

If malicious intent is detected, return EXACTLY:

{{
  "agent_name": "malicious_red",
  "malicious_agent_blocked": true,
  "block_message": "=== MALICIOUS INTENT DETECTED === This request cannot proceed because it appears harmful or abusive.",
  "reasons": ["reason1", "reason2"]
}}

2. If NOT malicious, return:

{{
  "agent_name": "malicious_red",
  "malicious_agent_blocked": false,
  "reasons": [],
  "attack_ideas": ["string"],
  "notes": "optional"
}}
"""


# ===============================================================
# RED TEAM WRAPPER CLASS
# ===============================================================

class RedTeam:
    def __init__(self) -> None:
        self.agent_prompts = RED_TEAM_AGENTS
        self.malicious_system_prompt = MALICIOUS_SYSTEM_PROMPT

    def run_security_agents(self, user_prompt: str) -> List[AgentResult]:
        results = []
        for name, system_prompt in self.agent_prompts.items():
            payload = (
                f"User prompt: {user_prompt}\n"
                f"Return JSON using the exact schema."
            )
            parsed = call_json_model(system_prompt, payload)
            results.append(
                AgentResult(
                    name=name,
                    role="red",
                    raw=json.dumps(parsed, indent=2),
                    parsed=parsed,
                )
            )
        return results

    def run_malicious_agent(self, user_prompt: str) -> AgentResult:
        parsed = call_json_model(self.malicious_system_prompt, f"User prompt: {user_prompt}")
        return AgentResult(
            name="malicious_red",
            role="malicious",
            raw=json.dumps(parsed, indent=2),
            parsed=parsed,
        )

    def run_all(self, user_prompt: str) -> List[AgentResult]:
        results = self.run_security_agents(user_prompt)
        results.append(self.run_malicious_agent(user_prompt))
        return results
