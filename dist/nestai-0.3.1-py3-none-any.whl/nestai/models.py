
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

from openai import OpenAI

# Shared client instance
_client: Optional[OpenAI] = None


def get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI()
    return _client


MODEL_NAME = os.getenv("NESTAI_MODEL", "gpt-4.1-mini")


def call_json_model(system_prompt: str, user_content: str) -> Dict[str, Any]:
    """
    Calls the OpenAI API and FORCES JSON output using response_format={"type": "json_object"}.
    If the model does not return valid JSON, an exception is raised.
    """

    client = get_client()

    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        temperature=0,
        response_format={"type": "json_object"},  # <<<< FORCE JSON MODE
    )

    content = response.choices[0].message.content

    try:
        return json.loads(content)
    except Exception as exc:
        raise ValueError(
            "Model did not return valid JSON.\n"
            f"Raw content:\n{content}"
        ) from exc


@dataclass
class AgentResult:
    name: str
    role: str  # "red", "blue", "malicious"
    raw: str
    parsed: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ControllerResult:
    blocked: bool
    block_message: Optional[str] = None
    final_prompt: Optional[str] = None
    rationale: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AuditEntry:
    project_id: str
    original_prompt: str
    final_prompt: Optional[str]
    controller_result: Dict[str, Any]
    red_team_results: List[Dict[str, Any]]
    blue_team_results: List[Dict[str, Any]]
    timestamp: float
    prev_hash: Optional[str] = None
    entry_hash: Optional[str] = None

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)