from __future__ import annotations

import json
from typing import List

from .models import AgentResult, ControllerResult, call_json_model

CONTROLLER_SYSTEM_PROMPT = """
You are the Controller Agent in a secure multi-agent system.

You receive:
- the original user prompt,
- a list of red-team findings (security risks and constraints),
- a list of blue-team defensive prompt rewrites.

Your tasks:

1. Read all red-team results and extract:
   - the union of all suggested_constraints,
   - the most critical risks that MUST be addressed.

2. Read all blue-team rewritten prompts and:
   - identify the common intent,
   - ignore outlier rewrites that contradict the majority,
   - merge the best phrasing and constraints.

3. Produce a single FINAL PROMPT that:
   - preserves the user's legitimate goal,
   - integrates strong security constraints,
   - explicitly addresses the red-team risks,
   - is clear, actionable, and safe.

Return a JSON object:
{
  "blocked": false,
  "final_prompt": "the unified, secure prompt to send to the code generator",
  "rationale": "why you chose these constraints and wording"
}

You MUST NOT set blocked=true here. Blocking is handled by the malicious agent upstream.
Always return valid JSON.
"""


class Controller:
    def __init__(self) -> None:
        self.system_prompt = CONTROLLER_SYSTEM_PROMPT

    def _check_malicious_block(
        self, red_team_results: List[AgentResult]
    ) -> ControllerResult:
        for result in red_team_results:
            if result.role == "malicious":
                parsed = result.parsed or {}
                if parsed.get("malicious_agent_blocked"):
                    # Use the model-provided block message if available, or a default.
                    block_message = parsed.get(
                        "block_message",
                        "=== MALICIOUS INTENT DETECTED ===\n"
                        "This request cannot proceed because it appears harmful or abusive.",
                    )
                    reasons = parsed.get("reasons")
                    if reasons:
                        block_message += "\n\nReasons:\n- " + "\n- ".join(reasons)
                    return ControllerResult(
                        blocked=True,
                        block_message=block_message,
                        final_prompt=None,
                        rationale=(
                            "Blocked by malicious agent based on detected harmful intent."
                        ),
                    )
        return ControllerResult(blocked=False)

    def unify(
        self,
        user_prompt: str,
        red_team_results: List[AgentResult],
        blue_team_results: List[AgentResult],
    ) -> ControllerResult:
        # Step 1: malicious intent gatekeeper
        maybe_block = self._check_malicious_block(red_team_results)
        if maybe_block.blocked:
            return maybe_block

        # Step 2: call LLM to merge prompts and constraints
        red_json = [r.parsed for r in red_team_results if r.role == "red"]
        blue_json = [b.parsed for b in blue_team_results]

        user_payload = {
            "original_prompt": user_prompt,
            "red_team": red_json,
            "blue_team": blue_json,
        }

        parsed = call_json_model(
            self.system_prompt,
            json.dumps(user_payload, indent=2),
        )

        final_prompt = parsed.get("final_prompt", user_prompt)
        rationale = parsed.get(
            "rationale",
            "Controller merged red-team and blue-team outputs.",
        )

        return ControllerResult(
            blocked=False,
            block_message=None,
            final_prompt=final_prompt,
            rationale=rationale,
        )
