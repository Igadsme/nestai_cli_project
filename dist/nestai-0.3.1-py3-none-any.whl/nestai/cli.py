from __future__ import annotations

import argparse
import sys
import os
import uuid
from typing import List

from .audit import append_history_entry
from .blue_team import BlueTeam
from .codegen import generate_code
from .controller import Controller
from .red_team import RedTeam


PREVIEW_LINES = 40  # Number of lines to show in preview window


def save_generated_code(code: str) -> str:
    """
    Saves the full generated code into a file in the project directory.
    """
    filename = f"nestai_output_{uuid.uuid4().hex[:8]}.py"
    filepath = os.path.join(os.getcwd(), filename)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(code)

    return filepath


def show_code_preview(code: str) -> str:
    """
    Return a preview (first N lines) of the generated code.
    """
    lines = code.split("\n")
    preview = "\n".join(lines[:PREVIEW_LINES])
    return preview


def run_nestai(user_prompt: str) -> int:
    red_team = RedTeam()
    blue_team = BlueTeam()
    controller = Controller()

    print("=== Original Prompt ===")
    print(user_prompt)
    print()

    # ---------- 1. RED TEAM ----------
    red_results = red_team.run_all(user_prompt)

    # ---------- 2. BLUE TEAM ----------
    blue_results = blue_team.run_all(user_prompt)

    # ---------- 3. CONTROLLER ----------
    controller_result = controller.unify(user_prompt, red_results, blue_results)

    # Blocked (malicious intent)
    if controller_result.blocked:
        print(controller_result.block_message or "Request blocked.")
        append_history_entry(
            original_prompt=user_prompt,
            final_prompt=None,
            controller_result=controller_result.to_dict(),
            red_team_results=[r.to_dict() for r in red_results],
            blue_team_results=[b.to_dict() for b in blue_results],
        )
        return 0

    final_prompt = controller_result.final_prompt
    print("=== Final Unified Prompt ===")
    print(final_prompt)
    print()

    # ---------- 4. CODE GENERATION ----------
    code_output = generate_code(final_prompt)

    # CODE PREVIEW
    preview = show_code_preview(code_output)
    print(f"=== Code Preview (first {PREVIEW_LINES} lines) ===")
    print(preview)
    print()

    # Save full code to a file
    filepath = save_generated_code(code_output)
    print(f"=== Full Code Saved To ===")
    print(filepath)
    print()

    # ---------- 5. AUDIT LOGGING ----------
    append_history_entry(
        original_prompt=user_prompt,
        final_prompt=final_prompt,
        controller_result=controller_result.to_dict(),
        red_team_results=[r.to_dict() for r in red_results],
        blue_team_results=[b.to_dict() for b in blue_results],
    )

    return 0


def main(argv: List[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="nestai",
        description="NestAI – AI for Secure Code (multi-agent CLI)",
    )
    parser.add_argument(
        "prompt",
        help="User prompt to send to NestAI (wrap in quotes).",
    )

    args = parser.parse_args(argv)

    try:
        exit_code = run_nestai(args.prompt)
    except Exception as exc:
        print(f"[nestai] Error: {exc}", file=sys.stderr)
        sys.exit(1)

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
